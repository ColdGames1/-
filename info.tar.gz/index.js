const { Client, GatewayIntentBits, Collection, ActivityType } = require('discord.js');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers, // Добавлен для guildMemberAdd
    ]
});

client.commands = new Collection();
const prefix = process.env.PREFIX || '!';
const errorChannelId = process.env.ERROR_CHANNEL_ID || '1368537072134127656';

// Загрузка команд и событий
async function loadModules() {
    const moduleFiles = await fs.readdir(path.join(__dirname, 'cmd')).then(files =>
        files.filter(file => file.endsWith('.js'))
    );

    for (const file of moduleFiles) {
        try {
            const module = require(`./cmd/${file}`);

            // Проверка на команду
            if (module.name && typeof module.execute === 'function') {
                client.commands.set(module.name, module);
                console.log(`Команда загружена: ${file} (${module.name})`);
            }
            // Проверка на событие
            else if (typeof module.setup === 'function') {
                module.setup(client);
                console.log(`Событие загружено: ${file}${module.name ? ` (${module.name})` : ''}`);
            }
            // Пропускаем неподходящие файлы без предупреждения
            else {
                console.log(`Файл ${file} пропущен: не является командой или событием`);
            }
        } catch (error) {
            console.error(`Ошибка загрузки файла ${file}: ${error.message}`);
            const errorChannel = client.channels.cache.get(errorChannelId);
            if (errorChannel) {
                errorChannel.send(`Ошибка загрузки файла ${file}:\n\`\`\`\n${error.message}\n\`\`\``).catch(err =>
                    console.error(`Ошибка отправки в канал ошибок: ${err.message}`)
                );
            }
        }
    }
}

// Обработка сообщений
client.on('messageCreate', async message => {
    if (message.author.bot || !message.guild || message.content.trim() === '') return;

    // Обновление цепи Маркова для команды ai
    const aiCommand = client.commands.get('ai');
    if (aiCommand && aiCommand.updateChain) {
        try {
            aiCommand.updateChain(message.content);
        } catch (error) {
            console.error('Ошибка обновления цепи Маркова:', error.message);
            const errorChannel = client.channels.cache.get(errorChannelId);
            if (errorChannel) {
                errorChannel.send(`Ошибка обновления цепи Маркова:\n\`\`\`\n${error.message}\n\`\`\``).catch(err =>
                    console.error(`Ошибка отправки в канал ошибок: ${err.message}`)
                );
            }
        }
    }

    // Обработка префикс-команд
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const commandName = args.shift()?.toLowerCase();
    if (!commandName) return;

    const command = client.commands.get(commandName);
    if (!command) return;

    try {
        await command.execute(message, args, client);
    } catch (error) {
        console.error(`Ошибка выполнения команды ${commandName}: ${error.message}`);
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel) {
            errorChannel.send(`Ошибка выполнения команды ${commandName}:\n\`\`\`\n${error.message}\n\`\`\``).catch(err =>
                console.error(`Ошибка отправки в канал ошибок: ${err.message}`)
            );
        }
        message.reply('Произошла ошибка при выполнении команды!').catch(err =>
            console.error(`Ошибка отправки ответа: ${err.message}`)
        );
    }
});

// Событие ready
client.once('ready', () => {
    console.log(`Бот вошёл как ${client.user.tag}`);
    client.user.setPresence({
        activities: [{ name: 'команды', type: ActivityType.Listening }],
        status: 'idle'
    });
});

// Инициализация
loadModules().then(() => {
    client.login(process.env.TOKEN).catch(error => {
        console.error(`Ошибка входа в Discord: ${error.message}`);
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel) {
            errorChannel.send(`Ошибка входа в Discord:\n\`\`\`\n${error.message}\n\`\`\``).catch(err =>
                console.error(`Ошибка отправки в канал ошибок: ${err.message}`)
            );
        }
        process.exit(1);
    });
}).catch(error => {
    console.error(`Ошибка инициализации бота: ${error.message}`);
    process.exit(1);
});