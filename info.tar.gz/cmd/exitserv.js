module.exports = {
  name: 'exitserv',
  description: 'Force the bot to leave a server (owner only)',
  async execute(message, args, client) {
    const ownerId = '1344681539354624093';
    if (message.author.id !== ownerId) {
      return message.reply('❌ This command is restricted to the bot owner.');
    }

    const guildId = args[0];
    if (!guildId) {
      return message.reply('Usage: `!exitserv <guild_id>`\nExample: `!exitserv 123456789012345678`');
    }

    try {
      const guild = await message.client.guilds.fetch(guildId);
      if (!guild) {
        return message.reply('❌ No server found with that ID.');
      }
      await guild.leave();
      message.reply(`✅ Bot has left the server **${guild.name}** (ID: ${guildId}).`);
    } catch (error) {
      console.error(`[CMD] Error in exitserv command (guild: ${guildId}): ${error.message}`);
      const errorChannel = client.channels.cache.get('1368537072134127656');
      if (errorChannel) {
        errorChannel.send(`Ошибка в команде exitserv (guild: ${guildId}):\n\`\`\`\n${error.message}\n\`\`\``).catch(console.error);
      }
      message.reply(`❌ An error occurred while trying to leave the server: ${error.message}`);
    }
  },
};