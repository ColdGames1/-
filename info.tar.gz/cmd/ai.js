const fs = require('fs');
const path = require('path');
const Tesseract = require('tesseract.js');
const pdfParse = require('pdf-parse');
const axios = require('axios');
const cheerio = require('cheerio');

const DATA_PATH = path.join(__dirname, '../brain.json');

// Загружаем или создаём пустую память
let markovData = {};
if (fs.existsSync(DATA_PATH)) {
    try {
        markovData = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
    } catch (error) {
        console.error('Ошибка чтения brain.json:', error);
    }
}

// Функция для извлечения текста из веб-страницы
async function extractTextFromUrl(url) {
    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);
        const text = $('p, h1, h2, h3, h4, h5, h6, article').map((i, el) => $(el).text()).get().join(' ');
        return text.replace(/\s+/g, ' ').trim();
    } catch (error) {
        console.error('Ошибка при загрузке URL:', error);
        return '';
    }
}

// Функция для извлечения текста из PDF
async function extractTextFromPdf(buffer) {
    try {
        const data = await pdfParse(buffer);
        return data.text.replace(/\s+/g, ' ').trim();
    } catch (error) {
        console.error('Ошибка при обработке PDF:', error);
        return '';
    }
}

// Функция для извлечения текста из изображений (PNG, JPG)
async function extractTextFromImage(url) {
    try {
        const { data: { text } } = await Tesseract.recognize(url, 'eng+rus', { logger: (m) => console.log(m) });
        return text.replace(/\s+/g, ' ').trim();
    } catch (error) {
        console.error('Ошибка при OCR:', error);
        return '';
    }
}

// Функция для обновления цепи Маркова
function updateChain(content) {
    const words = content.trim().split(/\s+/);
    for (let i = 0; i < words.length - 1; i++) {
        if (!markovData[words[i]]) markovData[words[i]] = [];
        markovData[words[i]].push(words[i + 1]);
    }
    try {
        fs.writeFileSync(DATA_PATH, JSON.stringify(markovData, null, 2), 'utf8');
    } catch (error) {
        console.error('Ошибка записи brain.json:', error);
        const errorChannel = client?.channels?.cache?.get('1391071178373730426');
        if (errorChannel) {
            errorChannel.send(`Ошибка записи brain.json:\n\`\`\`\n${error}\n\`\`\``).catch(console.error);
        }
    }
}

module.exports = {
    name: 'ии',
    description: 'Спросить локальный ИИ или обучить его на основе файлов/URL',
	cooldown: 5,
    async execute(message, args, client) {
        if (!message.guild) return;

        // Функция для генерации ответа
        const generateReply = (startWord = null) => {
            if (!Object.keys(markovData).length) return 'Я пока ничего не знаю...';
            let word = startWord && markovData[startWord] ? startWord : Object.keys(markovData)[Math.floor(Math.random() * Object.keys(markovData).length)];
            const reply = [word];
            let currentLength = word.length;

            while (currentLength < 1900) {
                const nextWords = markovData[reply[reply.length - 1]];
                if (!nextWords || !nextWords.length) break;
                const nextWord = nextWords[Math.floor(Math.random() * nextWords.length)];
                reply.push(nextWord);
                currentLength += nextWord.length + 1;
            }

            return reply.join(' ');
        };

        try {
            // Проверяем наличие вложений (файлов)
            if (message.attachments.size > 0) {
                const attachment = message.attachments.first();
                const fileUrl = attachment.url;
                let extractedText = '';

                if (attachment.name.endsWith('.pdf')) {
                    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
                    extractedText = await extractTextFromPdf(response.data);
                } else if (attachment.name.match(/\.(png|jpg|jpeg)$/i)) {
                    extractedText = await extractTextFromImage(fileUrl);
                } else {
                    return message.reply('Формат файла не поддерживается (поддерживаются PNG, JPG, PDF).');
                }

                if (extractedText) {
                    updateChain(extractedText);
                    return message.reply('Текст из файла успешно обработан и добавлен в базу знаний!');
                } else {
                    return message.reply('Не удалось извлечь текст из файла.');
                }
            }

            // Проверяем наличие URL в аргументах
            const urlRegex = /https?:\/\/[^\s]+/;
            const urlMatch = args.join(' ').match(urlRegex);
            if (urlMatch) {
                const url = urlMatch[0];
                const extractedText = await extractTextFromUrl(url);
                if (extractedText) {
                    updateChain(extractedText);
                    return message.reply('Текст с веб-страницы успешно обработан и добавлен в базу знаний!');
                } else {
                    return message.reply('Не удалось извлечь текст с веб-страницы.');
                }
            }

            // Если нет файлов или URL, обрабатываем текстовую команду
            if (!args.length) {
                return message.reply('Напишите что-нибудь после `!ии`, прикрепите файл или укажите URL!');
            }

            const startWord = args[0].trim().split(/\s+/)[0];
            const reply = generateReply(startWord);
            if (reply.length > 2000) {
                return message.reply(reply.slice(0, 1997) + '...');
            }
            await message.reply(`💬 ${reply}`);

        } catch (error) {
            console.error('Ошибка обработки команды !ии:', error);
            const errorChannel = client.channels.cache.get('1368537072134127656');
            if (errorChannel) {
                errorChannel.send(`Ошибка обработки команды !ии:\n\`\`\`\n${error}\n\`\`\``).catch(console.error);
            }
            message.reply('Ошибка при обработке команды!').catch(console.error);
        }
    },
    updateChain
};