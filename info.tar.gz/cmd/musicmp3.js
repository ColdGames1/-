const { Client, Message } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Инициализация базы данных SQLite
const db = new sqlite3.Database('./music_queue.db', (err) => {
    if (err) {
        console.error('Ошибка при открытии базы данных:', err.message);
    } else {
        db.run(`CREATE TABLE IF NOT EXISTS queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT NOT NULL,
            song_path TEXT NOT NULL
        )`, (err) => {
            if (err) console.error('Ошибка при создании таблицы:', err.message);
        });
    }
});

// Объект для хранения плееров и соединений
const players = new Map();
const connections = new Map();

module.exports = {
    name: 'music',
    description: 'Команды для управления музыкой: !autoplay, !skip, !stop',
    async execute(message, args) {
        const command = args[0]?.toLowerCase();
        const guildId = message.guild.id;
        const voiceChannel = message.member.voice.channel;

        if (!voiceChannel) {
            return message.reply('Вы должны быть в голосовом канале!');
        }

        // Функция для воспроизведения следующего трека
        const playNext = async (guildId) => {
            const player = players.get(guildId);
            if (!player) return;

            db.get(`SELECT song_path FROM queue WHERE guild_id = ? ORDER BY id LIMIT 1`, [guildId], (err, row) => {
                if (err) {
                    console.error('Ошибка при получении трека из очереди:', err.message);
                    return;
                }

                if (!row) {
                    // Если очередь пуста, пытаемся загрузить все .mp3 файлы из папки music
                    const musicFolder = path.join(__dirname, '../music');
                    const files = fs.readdirSync(musicFolder).filter(file => file.endsWith('.mp3'));
                    if (files.length === 0) {
                        message.channel.send('В папке music нет .mp3 файлов!');
                        connections.get(guildId)?.destroy();
                        players.delete(guildId);
                        connections.delete(guildId);
                        return;
                    }

                    // Добавляем все .mp3 файлы в очередь
                    files.forEach(file => {
                        db.run(`INSERT INTO queue (guild_id, song_path) VALUES (?, ?)`, [guildId, path.join(musicFolder, file)]);
                    });

                    // Берем первый трек
                    db.get(`SELECT song_path FROM queue WHERE guild_id = ? ORDER BY id LIMIT 1`, [guildId], (err, row) => {
                        if (row) {
                            const resource = createAudioResource(row.song_path);
                            player.play(resource);
                            message.channel.send(`Сейчас играет: ${path.basename(row.song_path)}`);
                            // Удаляем воспроизведенный трек из очереди
                            db.run(`DELETE FROM queue WHERE guild_id = ? AND song_path = ?`, [guildId, row.song_path]);
                        }
                    });
                } else {
                    const resource = createAudioResource(row.song_path);
                    player.play(resource);
                    message.channel.send(`Сейчас играет: ${path.basename(row.song_path)}`);
                    db.run(`DELETE FROM queue WHERE guild_id = ? AND song_path = ?`, [guildId, row.song_path]);
                }
            });
        };

        // Обработка команд
        if (command === 'autoplay') {
            // Подключение к голосовому каналу
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: guildId,
                adapterCreator: message.guild.voiceAdapterCreator,
            });

            // Создаем аудиоплеер
            const player = createAudioPlayer();

            // Сохраняем соединение и плеер
            connections.set(guildId, connection);
            players.set(guildId, player);

            // Подписываемся на события плеера
            player.on(AudioPlayerStatus.Idle, () => {
                playNext(guildId); // Автопроигрывание следующего трека
            });

            player.on('error', (error) => {
                console.error('Ошибка плеера:', error.message);
                message.channel.send('Произошла ошибка при воспроизведении.');
            });

            connection.on(VoiceConnectionStatus.Disconnected, () => {
                players.delete(guildId);
                connections.delete(guildId);
                db.run(`DELETE FROM queue WHERE guild_id = ?`, [guildId]);
            });

            // Подключаем плеер к соединению
            connection.subscribe(player);

            // Начинаем воспроизведение
            playNext(guildId);
            message.channel.send('Автопроигрывание запущено!');
        }

        else if (command === 'skip') {
            const player = players.get(guildId);
            if (!player) {
                return message.reply('Сейчас ничего не играет!');
            }
            player.stop(); // Останавливаем текущий трек, событие Idle вызовет playNext
            message.channel.send('Трек пропущен!');
        }

        else if (command === 'stop') {
            const player = players.get(guildId);
            const connection = connections.get(guildId);
            if (!player || !connection) {
                return message.reply('Сейчас ничего не играет!');
            }
            player.stop();
            connection.destroy();
            players.delete(guildId);
            connections.delete(guildId);
            db.run(`DELETE FROM queue WHERE guild_id = ?`, [guildId]);
            message.channel.send('Воспроизведение остановлено, бот покинул канал.');
        }

        else {
            message.reply('Используйте: !autoplay, !skip или !stop');
        }
    },
};