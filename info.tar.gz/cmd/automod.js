const { Client, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'automod',
  description: 'Automatic bot/self-bot detection on member join',
  setup(client) {
    // Событие при входе участника на сервер
    client.on('guildMemberAdd', async (member) => {
      const log = (...args) => console.log(`[Automod ${member.user.tag}]`, ...args);
      const targetChannelId = '1376226234320556153'; // Канал для анализа
      const ownerId = '1344681539354624093'; // Твой ID для пинга
      const guild = member.guild;

      log('New member joined.');

      try {
        // Проверяем, является ли участник официальным ботом
        if (member.user.bot) {
          log('Member is an official bot.');
          await restrictAccess(member, 'Official bot detected.');
          return;
        }

        // Проверяем на селф-бота через активность в канале
        const channel = await guild.channels.fetch(targetChannelId).catch((err) => {
          log('Error fetching channel:', err.message);
          return null;
        });

        if (!channel) {
          log('Target channel not found or inaccessible.');
          await notifyOwner(client, ownerId, `Failed to access channel ${targetChannelId} for ${member.user.tag}.`);
          return;
        }

        // Проверяем последние сообщения в канале
        let isSelfBot = false;
        try {
          const messages = await channel.messages.fetch({ limit: 100 });
          const userMessages = messages.filter((msg) => msg.author.id === member.id);

          // Эвристика для селф-бота
          if (userMessages.size > 0) {
            const timestamps = userMessages.map((msg) => msg.createdTimestamp);
            const timeSpan = Math.max(...timestamps) - Math.min(...timestamps);
            const messageRate = userMessages.size / (timeSpan / 1000); // Сообщений в секунду

            // Проверяем частоту сообщений (например, >1 сообщения в секунду)
            if (messageRate > 1) {
              isSelfBot = true;
              log('High message rate detected:', messageRate);
            }

            // Проверяем содержание сообщений
            for (const [, msg] of userMessages) {
              const content = msg.content.toLowerCase();
              // Подозрительные паттерны: команды, эмбеды, вебхуки
              if (
                content.startsWith('!') ||
                content.startsWith('.') ||
                content.startsWith('/') ||
                msg.embeds.length > 0 ||
                msg.webhookId
              ) {
                isSelfBot = true;
                log('Suspicious message content:', content);
                break;
              }
            }
          }
        } catch (err) {
          log('Error fetching messages:', err.message);
          await notifyOwner(client, ownerId, `Failed to fetch messages in ${targetChannelId} for ${member.user.tag}: ${err.message}`);
        }

        // Если обнаружен селф-бот, ограничиваем доступ
        if (isSelfBot) {
          log('Member is a suspected self-bot.');
          await restrictAccess(member, 'Suspected self-bot detected.');
        } else {
          log('Member appears to be a clean user.');
        }
      } catch (err) {
        log('General error:', err.message);
        await notifyOwner(client, ownerId, `Error processing ${member.user.tag}: ${err.message}`);
      }
    });
  },
};

// Функция для ограничения доступа
async function restrictAccess(member, reason) {
  const log = (...args) => console.log(`[Restrict ${member.user.tag}]`, ...args);
  const guild = member.guild;

  // Проверяем права бота
  if (!guild.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
    log('Bot lacks MANAGE_CHANNELS permission.');
    await notifyOwner(
      member.client,
      '1344681539354624093',
      `Failed to restrict ${member.user.tag}: Bot lacks MANAGE_CHANNELS permission.`
    );
    return;
  }

  // Перебираем все каналы сервера
  for (const [, channel] of guild.channels.cache) {
    try {
      // Пропускаем категории и недоступные каналы
      if (channel.isThread() || !channel.permissionsFor(guild.me).has(PermissionsBitField.Flags.ManageChannels)) {
        continue;
      }

      // Скрываем канал и запрещаем писать
      await channel.permissionOverwrites.edit(member.id, {
        ViewChannel: false,
        SendMessages: false,
      });
      log(`Restricted access to channel ${channel.name}.`);
    } catch (err) {
      log(`Error restricting channel ${channel.name}:`, err.message);
      await notifyOwner(
        member.client,
        '1344681539354624093',
        `Failed to restrict ${member.user.tag} in ${channel.name}: ${err.message}`
      );
    }
  }

  log('Access restriction completed.');
}

// Функция для уведомления владельца
async function notifyOwner(client, ownerId, message) {
  try {
    const owner = await client.users.fetch(ownerId);
    await owner.send(`⚠️ Automod Alert: ${message}`);
    console.log(`Notified owner: ${message}`);
  } catch (err) {
    console.error(`Failed to notify owner ${ownerId}:`, err.message);
  }
}