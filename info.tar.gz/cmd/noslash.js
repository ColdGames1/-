module.exports = {
  name: 'noslash',
  description: 'Disable a slash command by ID',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('❌ You need Administrator permissions to use this command.');
    }

    const commandId = args[0];
    if (!commandId) {
      return message.reply('Usage: `!noslash <slash_command_id>`\nExample: `!noslash 123456789012345678`');
    }

    try {
      const command = await message.guild.commands.fetch(commandId);
      if (!command) {
        return message.reply('❌ No slash command found with that ID.');
      }
      await message.guild.commands.delete(commandId);
      message.reply(`✅ Slash command with ID **${commandId}** has been disabled.`);
    } catch (error) {
      console.error(`[CMD] Error in noslash command (guild: ${message.guild.id}): ${error.message}`);
      const errorChannel = client.channels.cache.get('1368537072134127656');
      if (errorChannel) {
        errorChannel.send(`Ошибка в команде noslash (guild: ${message.guild.id}):\n\`\`\`\n${error.message}\n\`\`\``).catch(console.error);
      }
      message.reply(`❌ An error occurred while disabling the slash command: ${error.message}`);
    }
  },
};