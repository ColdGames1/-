const { Client, Message, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, 'cmd.json');

module.exports = {
    name: 'cmd',
    description: 'Управление командами (вкл/выкл)',
    usage: '!cmd <command> <on/off> [role_id on/off]',
    permissions: PermissionFlagsBits.Administrator,
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('У вас недостаточно прав для использования этой команды!');
        }

        if (args.length < 2) {
            return message.reply('Использование: `!cmd <command> <on/off> [role_id on/off]`');
        }

        const commandName = args[0].toLowerCase();
        const status = args[1].toLowerCase();
        const roleId = args[2] && !['on', 'off'].includes(args[2].toLowerCase()) ? args[2] : null;
        const roleStatus = roleId && args[3] ? args[3].toLowerCase() : null;

        if (!['on', 'off'].includes(status)) {
            return message.reply('Статус должен быть `on` или `off`!');
        }

        // Чтение cmd.json
        let config = {};
        if (fs.existsSync(configPath)) {
            config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        } else {
            config.commands = {};
            fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
        }

        // Проверка существования команды
        const commands = client.commands;
        if (!commands.has(commandName)) {
            return message.reply(`Команда **${commandName}** не найдена!`);
        }

        // Инициализация команды в конфиге, если её нет
        if (!config.commands[commandName]) {
            config.commands[commandName] = {
                enabled: true, // Команда включена по умолчанию
                roles: {} // Настройки для ролей
            };
        }

        if (roleId) {
            // Проверка валидности ID роли
            try {
                const role = await message.guild.roles.fetch(roleId);
                if (!role) {
                    return message.reply(`Роль с ID **${roleId}** не найдена!`);
                }
                if (!['on', 'off'].includes(roleStatus)) {
                    return message.reply('Статус роли должен быть `on` или `off`!');
                }

                // Настройка для конкретной роли
                config.commands[commandName].roles[roleId] = roleStatus === 'on';
                await message.reply({
                    content: `Команда **${commandName}** теперь **${roleStatus === 'on' ? 'включена' : 'выключена'}** для роли **${role.name}**.`,
                    allowedMentions: { repliedUser: false }
                });
            } catch (error) {
                return message.reply(`Ошибка: неверный ID роли **${roleId}**!`);
            }
        } else {
            // Глобальная настройка
            config.commands[commandName].enabled = status === 'on';
            await message.reply({
                content: `Команда **${commandName}** теперь **${status === 'on' ? 'включена' : 'выключена'}** глобально.`,
                allowedMentions: { repliedUser: false }
            });
        }

        // Сохранение изменений в cmd.json
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    }
};