const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  entersState,
  VoiceConnectionStatus
} = require('@discordjs/voice');
const play = require('play-dl');

const queue = new Map();

module.exports = {
  name: 'mus',
  description: 'Музыкальные команды',
  async execute(message, args) {
    const command = args[0];
    const serverQueue = queue.get(message.guild.id);

    if (command === 'play') {
      const url = args[1];
      if (!url) return message.channel.send('Укажи ссылку на YouTube!');

      const voiceChannel = message.member.voice.channel;
      if (!voiceChannel) return message.reply('Зайди в голосовой канал!');

      const song = await getSong(url);
      if (!song) return message.channel.send('Не удалось получить трек.');

      if (!serverQueue) {
        const queueContruct = {
          voiceChannel,
          connection: null,
          player: createAudioPlayer(),
          songs: [],
          playing: true
        };

        queue.set(message.guild.id, queueContruct);
        queueContruct.songs.push(song);

        try {
          const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: message.guild.id,
            adapterCreator: message.guild.voiceAdapterCreator
          });

          await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
          queueContruct.connection = connection;

          connection.subscribe(queueContruct.player);
          playSong(message.guild.id, queueContruct.songs[0]);
        } catch (err) {
          console.error(err);
          queue.delete(message.guild.id);
          return message.channel.send('Ошибка подключения к голосовому каналу.');
        }
      } else {
        serverQueue.songs.push(song);
        return message.channel.send(`Добавлено в очередь: **${song.title}**`);
      }
    }

    if (command === 'skipn') {
      if (!serverQueue) return message.channel.send('Очередь пуста.');
      serverQueue.player.stop();
    }

    if (command === 'stopn') {
      if (!serverQueue) return message.channel.send('Очередь уже пуста.');
      serverQueue.songs = [];
      serverQueue.player.stop();
      serverQueue.connection.destroy();
      queue.delete(message.guild.id);
      message.channel.send('Музыка остановлена.');
    }
  }
};

async function getSong(url) {
  try {
    const info = await play.video_info(url);
    const stream = await play.stream(url);

    return {
      title: info.video_details.title,
      url,
      stream: stream.stream,
      type: stream.type
    };
  } catch (err) {
    console.error('Ошибка получения трека:', err);
    return null;
  }
}

function playSong(guildId, song) {
  const serverQueue = queue.get(guildId);
  if (!song) {
    serverQueue.connection.destroy();
    queue.delete(guildId);
    return;
  }

  const resource = createAudioResource(song.stream, { inputType: song.type });
  serverQueue.player.play(resource);

  serverQueue.player.once(AudioPlayerStatus.Idle, () => {
    serverQueue.songs.shift();
    playSong(guildId, serverQueue.songs[0]);
  });
}
