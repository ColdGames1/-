// cmd/roleplay.js
const { Client, Message } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, '../chars.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Ошибка подключения к базе данных:', err.message);
    } else {
        console.log('Подключено к базе данных chars.db');
        db.run(`
            CREATE TABLE IF NOT EXISTS characters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                char_name TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                UNIQUE(user_id, char_name, guild_id)
            )
        `, (err) => {
            if (err) {
                console.error('Ошибка создания таблицы:', err.message);
            }
        });
    }
});

module.exports = {
    name: 'roleplay',
    description: 'Система ролевого чата',
    async execute(message, args, client) { // Исправлена сигнатура
        const command = args[0]?.toLowerCase();

        if (command === 'crchar') {
            const charName = args.slice(1).join(' ').trim();
            if (!charName) {
                return message.reply('Укажите имя персонажа!');
            }
            if (charName.length > 50) {
                return message.reply('Имя персонажа слишком длинное (макс. 50 символов)!');
            }

            db.run(
                `INSERT INTO characters (user_id, char_name, guild_id) VALUES (?, ?, ?)`,
                [message.author.id, charName, message.guild.id],
                function (err) {
                    if (err) {
                        if (err.message.includes('UNIQUE constraint')) {
                            return message.reply(`Персонаж "${charName}" уже существует!`);
                        }
                        console.error('Ошибка создания персонажа:', err.message);
                        const errorChannel = client.channels.cache.get('1368537072134127656');
                        if (errorChannel) {
                            errorChannel.send(`Ошибка создания персонажа:\n\`\`\`\n${err.message}\n\`\`\``).catch(console.error);
                        }
                        return message.reply('Ошибка при создании персонажа.');
                    }
                    message.reply(`Персонаж "${charName}" успешно создан!`);
                }
            );
        } else if (command === 'delchar') {
            const charName = args.slice(1).join(' ').trim();
            if (!charName) {
                return message.reply('Укажите имя персонажа!');
            }

            db.run(
                `DELETE FROM characters WHERE user_id = ? AND char_name = ? AND guild_id = ?`,
                [message.author.id, charName, message.guild.id],
                function (err) {
                    if (err) {
                        console.error('Ошибка удаления персонажа:', err.message);
                        const errorChannel = client.channels.cache.get('1368537072134127656');
                        if (errorChannel) {
                            errorChannel.send(`Ошибка удаления персонажа:\n\`\`\`\n${err.message}\n\`\`\``).catch(console.error);
                        }
                        return message.reply('Ошибка при удалении персонажа.');
                    }
                    if (this.changes === 0) {
                        return message.reply(`Персонаж "${charName}" не найден!`);
                    }
                    message.reply(`Персонаж "${charName}" успешно удалён!`);
                }
            );
        } else if (command === 'listchars') {
            db.all(
                `SELECT char_name FROM characters WHERE user_id = ? AND guild_id = ?`,
                [message.author.id, message.guild.id],
                (err, rows) => {
                    if (err) {
                        console.error('Ошибка получения списка персонажей:', err.message);
                        const errorChannel = client.channels.cache.get('1368537072134127656');
                        if (errorChannel) {
                            errorChannel.send(`Ошибка получения списка персонажей:\n\`\`\`\n${err.message}\n\`\`\``).catch(console.error);
                        }
                        return message.reply('Ошибка при получении списка персонажей.');
                    }
                    if (rows.length === 0) {
                        return message.reply('У вас нет персонажей!');
                    }
                    const charList = rows.map(row => row.char_name).join(', ');
                    message.reply(`Ваши персонажи: ${charList}`);
                }
            );
        } else {
            message.reply(
                'Использование:\n' +
                '`!roleplay crchar [имя_персонажа]` - создать персонажа\n'
                +
                '`!roleplay delchar [имя_персонажа]` - удалить персонажа\n'
                +
                '`!roleplay listchars` - список ваших персонажей\n'
                +
                '`[имя_персонажа] : [сообщение]` - говорить от имени персонажа'
            );
        }
    },
    async handleMessage(client, message) {
        if (message.author.bot) return;

        const match = message.content.match(/^\[([^\]\[\\\/:*?"<>|]+)\]\s*:\s*(.+)$/);
        if (!match) return;

        const charName = match[1].trim();
        const roleplayMessage = match[2].trim();

        if (!roleplayMessage) {
            return message.reply('Укажите сообщение для персонажа!');
        }

        db.get(
            `SELECT char_name FROM characters WHERE user_id = ? AND char_name = ? AND guild_id = ?`,
            [message.author.id, charName, message.guild.id],
            (err, row) => {
                if (err) {
                    console.error('Ошибка проверки персонажа:', err.message);
                    const errorChannel = client.channels.cache.get('1368537072134127656');
                    if (errorChannel) {
                        errorChannel.send(`Ошибка проверки персонажа:\n\`\`\`\n${err.message}\n\`\`\``).catch(console.error);
                    }
                    return message.reply('Ошибка при отправке сообщения.');
                }
                if (!row) {
                    return message.reply(`Персонаж "${charName}" не найден! Создайте его с помощью !roleplay crchar.`);
                }

                if (!message.channel.permissionsFor(client.user).has('SEND_MESSAGES')) {
                    return message.author.send(`Ошибка: у меня нет прав на отправку сообщений в канале ${message.channel.name}!`).catch(console.error);
                }

                message.channel.send({
                    content: `**${charName}**: ${roleplayMessage}`,
                    allowedMentions: { parse: [] }
                }).then(() => {
                    if (message.channel.permissionsFor(client.user).has('MANAGE_MESSAGES')) {
                        message.delete().catch(err => {
                            console.error(`Ошибка удаления сообщения: ${err}`);
                            const errorChannel = client.channels.cache.get('1368537072134127656');
                            if (errorChannel) {
                                errorChannel.send(`Ошибка удаления сообщения:\n\`\`\`\n${err}\n\`\`\``).catch(console.error);
                            }
                        });
                    }
                }).catch(err => {
                    console.error(`Ошибка отправки ролевого сообщения: ${err}`);
                    const errorChannel = client.channels.cache.get('1368537072134127656');
                    if (errorChannel) {
                        errorChannel.send(`Ошибка отправки ролевого сообщения:\n\`\`\`\n${err}\n\`\`\``).catch(console.error);
                    }
                });
            }
        );
    }
};