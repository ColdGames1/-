// cmd/getemoji.js

module.exports = {
  name: 'getemoji',
  description: 'Получает эмодзи по его имени или ID',
  usage: '!getemoji <имя_или_ID>',
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('Укажите имя или ID эмодзи! Использование: `!getemoji <имя_или_ID>`');
    }

    const emojiName = args[0];
    const emoji = message.guild.emojis.cache.find(e => e.name === emojiName || e.id === emojiName);

    if (emoji) {
      await message.channel.send(`Найден эмодзи: <:${emoji.name}:${emoji.id}>`);
    } else {
      await message.channel.send('Эмодзи не найдено!');
    }
  },
};