//const radioStations = {
  //авторадио: 'https://online2.gkvr.ru:8001/avtoradio_mzd_64.aac',
  //EDM: 'https://radiorecord.hostingradio.ru/top100edm96.aac',
  //шокорадио: 'https://choco.hostingradio.ru:10010/fm',
  //hitradio: 'http://hit.trkeurasia.ru:8000/hit128',
  //tver: 'http://online.tv-pilot.ru:1027/pilotradio',
  //юмор: 'https://radio.mixnews.lv/jumorfm_192',
  //юлдаш: 'https://radio.mediacdn.ru/uldash.mp3',
  //Cyth: 'http://stream.dar.fm/171408',
  //NCS1: 'https://boxradio-edge-05.streamafrica.net/ncs',
  //NCS2: 'https://100x.stream.laut.fm/100x?t302=2025-06-12_09-06-51&uuid=05bf1d9a-3155-4b81-84dd-d76cde6d42f8'
//};

const { Client } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, getVoiceConnection } = require('@discordjs/voice');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs').promises;
const path = require('path');

// Создаём экземпляр Radio один раз
class Radio {
    constructor(client) {
        this.client = client;
        this.dbPath = path.join(__dirname, 'radio.db');
        this.cooldowns = new Map();
        this.conn = null;
        this.setupDatabase();
    }

    setupDatabase() {
        try {
            // Синхронное подключение к базе
            this.conn = new sqlite3.Database(this.dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
                if (err) {
                    console.error('Ошибка подключения к radio.db:', err.message);
                    return;
                }
                console.log('Подключение к radio.db успешно');
            });

            // Создание таблицы
            this.conn.run(`
                CREATE TABLE IF NOT EXISTS radio_stations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    url TEXT NOT NULL UNIQUE
                )
            `, (err) => {
                if (err) {
                    console.error('Ошибка при создании таблицы:', err.message);
                    return;
                }
                console.log('Таблица radio_stations готова'); // Выводится только один раз
            });

            // Установка прав 755
            fs.chmod(this.dbPath, 0o755)
                .then(() => console.log('Права на radio.db установлены: 755'))
                .catch((err) => console.error('Ошибка при установке прав 755 на radio.db:', err.message));
        } catch (err) {
            console.error('Ошибка настройки базы данных:', err.message);
        }
    }

    async addRadio(message, args) {
        if (!args[0] || !args[1]) {
            return message.channel.send('Используй: !add_radio <название> <URL>');
        }

        const name = args[0];
        const url = args[1];

        this.conn.get('SELECT * FROM radio_stations WHERE url = ?', [url], async (err, row) => {
            if (err) {
                console.error('Ошибка при проверке URL:', err.message);
                return message.channel.send('Произошла ошибка при добавлении станции.');
            }

            if (row) {
                return message.channel.send('Эта радиостанция уже добавлена.');
            }

            this.conn.run('INSERT INTO radio_stations (name, url) VALUES (?, ?)', [name, url], async (err) => {
                if (err) {
                    console.error('Ошибка при добавлении станции:', err.message);
                    return message.channel.send('Не удалось добавить радиостанцию.');
                }
                await message.channel.send(`Радиостанция "${name}" добавлена с URL: ${url}`);
            });
        });
    }

    async removeRadio(message, args) {
        if (!args[0]) {
            return message.channel.send('Используй: !remove_radio <название>');
        }

        const name = args[0];

        this.conn.run('DELETE FROM radio_stations WHERE name = ?', [name], async (err) => {
            if (err) {
                console.error('Ошибка при удалении станции:', err.message);
                return message.channel.send('Произошла ошибка при удалении станции.');
            }

            if (this.conn.changes === 0) {
                return message.channel.send('Радиостанция с таким названием не найдена.');
            }

            await message.channel.send(`Радиостанция "${name}" удалена.`);
        });
    }

    async radio(message, args) {
        // Проверка кулдауна
        const userId = message.author.id;
        const now = Date.now();
        const cooldownAmount = 5 * 1000;

        if (this.cooldowns.has(userId)) {
            const expirationTime = this.cooldowns.get(userId) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = (expirationTime - now) / 1000;
                return message.channel.send(`Подожди ${timeLeft.toFixed(1)} секунд перед повторным использованием команды.`);
            }
        }
        this.cooldowns.set(userId, now);
        setTimeout(() => this.cooldowns.delete(userId), cooldownAmount);

        const stationName = args.join(' ');

        if (!stationName) {
            // Показать список станций
            this.conn.all('SELECT name FROM radio_stations', async (err, rows) => {
                if (err) {
                    console.error('Ошибка при получении списка станций:', err.message);
                    return message.channel.send('Произошла ошибка при получении списка станций.');
                }

                if (rows.length === 0) {
                    return message.channel.send('📻 Радиостанций нет.');
                }

                const messageText = '📻 Доступные радиостанции:\n' + rows.map(row => `• ${row.name}`).join('\n');
                await message.channel.send(messageText);
            });
            return;
        }

        // Проверка голосового канала пользователя
        if (!message.member?.voice?.channel) {
            return message.channel.send('Ты должен быть в голосовом канале!');
        }

        // Поиск станции
        this.conn.get('SELECT url FROM radio_stations WHERE name = ?', [stationName], async (err, row) => {
            if (err) {
                console.error('Ошибка при поиске станции:', err.message);
                return message.channel.send('Произошла ошибка при поиске станции.');
            }

            if (!row) {
                return message.channel.send(`Радиостанция "${stationName}" не найдена. Добавь её с помощью !add_radio.`);
            }

            try {
                // Подключение к голосовому каналу
                const connection = joinVoiceChannel({
                    channelId: message.member.voice.channel.id,
                    guildId: message.guild.id,
                    adapterCreator: message.guild.voiceAdapterCreator,
                });

                const player = createAudioPlayer();
                const resource = createAudioResource(row.url, { inputType: 'ffmpeg' });
                player.play(resource);
                connection.subscribe(player);

                player.on(AudioPlayerStatus.Playing, () => {
                    message.channel.send(`Сейчас играет: ${stationName}`);
                });

                player.on('error', (error) => {
                    console.error('Ошибка воспроизведения:', error.message);
                    message.channel.send('Ошибка при воспроизведении радиостанции.');
                    connection.destroy();
                });

                connection.on('stateChange', (oldState, newState) => {
                    if (newState.status === 'disconnected') {
                        connection.destroy();
                    }
                });
            } catch (error) {
                console.error('Ошибка подключения к голосовому каналу:', error.message);
                message.channel.send('Не удалось подключиться к голосовому каналу.');
            }
        });
    }

    async stopRadio(message) {
        // Проверка, находится ли бот в голосовом канале
        const connection = getVoiceConnection(message.guild.id);
        if (!connection) {
            return message.channel.send('Я не в голосовом канале.');
        }

        try {
            connection.destroy();
            await message.channel.send('Радио остановлено, я покинул голосовой канал.');
        } catch (error) {
            console.error('Ошибка при остановке радио:', error.message);
            message.channel.send('Произошла ошибка при остановке радио.');
        }
    }
}

// Создаём экземпляр Radio один раз при загрузке модуля
let radioInstance = null;

module.exports = {
    name: 'radio',
    async execute(message, args, client) {
        // Инициализируем Radio только один раз
        if (!radioInstance) {
            radioInstance = new Radio(client);
        }

        // Проверяем подкоманды
        const command = args.length > 0 && ['add_radio', 'remove_radio', 'stopradio'].includes(args[0].toLowerCase()) ? args.shift().toLowerCase() : 'radio';

        if (command === 'add_radio') {
            await radioInstance.addRadio(message, args);
        } else if (command === 'remove_radio') {
            await radioInstance.removeRadio(message, args);
        } else if (command === 'stopradio') {
            await radioInstance.stopRadio(message);
        } else {
            await radioInstance.radio(message, args);
        }
    }
};