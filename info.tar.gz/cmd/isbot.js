// cmd/isbot.js

module.exports = {
  name: 'isbot',
  description: 'Проверяет, является ли пользователь ботом',
  usage: '!isbot [упоминание_пользователя]',
  async execute(message, args, client) {
    let user = message.author;

    if (message.mentions.users.size > 0) {
      user = message.mentions.users.first();
    }

    const isBot = user.bot;
    await message.channel.send(`${user.tag} ${isBot ? 'является ботом!' : 'не бот!'}`);
  },
};